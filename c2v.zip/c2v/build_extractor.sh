#!/usr/bin/env bash
cd JavaExtractor/JPredict
mvn clean package
cd ../../