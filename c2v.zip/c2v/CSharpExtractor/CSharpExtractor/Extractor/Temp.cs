﻿namespace Extractor
{
    class Temp
    {
        class NestedClass
        {
            void fooBar()
            {
                a.b = c;
            }
        }
    }
}
